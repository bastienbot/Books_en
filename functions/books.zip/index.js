const books = require('./books_en_entrepreneurship.json');

function compare(a, b) {
  if (a.rating < b.rating) return 1;
  if (a.rating > b.rating) return -1;
  return 0;
}
// 1. recherche titre
// 2. coup de coeur
// 3. categorie
// 4. taille du livre
// 5. trié par rating
const findBooks = async function findBooks(event) {
  if (event.id) {
    const book = books.filter((b) => (b.id === event.id));
    if (book.length > 0) return book[0];
  }

  let res = books;
  if (event.search && event.search.length > 0) {
    res = res.filter((b) => b.title.toLowerCase().indexOf(event.search.toLowerCase()) !== -1);
  }
  if (event.fav) {
    res = res.filter((b) => b.fav.length > 0);
  }
  if (event.category && event.category.length > 0 && event.category !== 'any') {
    res = res.filter((b) => b.category === event.category);
  }
  if (event.size && event.size !== 'any') {
    res = res.filter((b) => b.size < event.size);
  }
  if (event.is_sorted) {
    res = res.sort(compare);
  } else {
    res = res.sort(() => Math.random() - 0.5);
  }
  return res.slice(0, 5);
};
exports.handler = async (event) => findBooks(event);
